def do_someting():
    print("doing something")
